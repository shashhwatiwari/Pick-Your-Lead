Want to collect ideas before the meeting, do a quick pulse check or get feedback after the session? Our app helps you do that in a clean, organized and concise manner.
